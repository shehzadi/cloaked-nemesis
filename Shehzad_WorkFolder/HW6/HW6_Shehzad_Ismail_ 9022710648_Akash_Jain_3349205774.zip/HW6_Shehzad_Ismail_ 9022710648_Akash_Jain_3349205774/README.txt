JAIN, AKASH: 3349 2057 74
ISMAIL, SHEHZAD: 9022 7106 48


Run the command "make" to compile the readckt.c code
	-The output program a.out is created.
Run the a.out program

The following command sequences are required to create the fault list, vector file and report file.

- read <circuit_name>
- lev : Performs Levelization
- pc  : Prints the values at the output
- ppc : performs preprocessing for initialization.
- atpg : Checks the fault site and generates an ATPG vector for the same.

Complete code does not work.
